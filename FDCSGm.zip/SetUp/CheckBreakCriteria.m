function [answer,T] = CheckBreakCriteria(it,T,D,M,Pl,ID,Py)

answer      = 'no';

T.tind = find(T.time(1:it) >= (T.time(it)-0.02),1,'first');

if (T.tind > 1)    
    epsV    =   std(D.meanV(T.tind:it));
else
    epsV    =   1e3;
end

if (mod(it,10)==0||it==1)
    disp(['eps_V = ',sprintf('%g',epsV)])
end

if (T.time(it) > T.tmax)
    set(figure(1),'position',[1.8,1.8,766.4,780.8]);
    h           =   figure(1);
    disp('Maximale Zeit erreicht. Zeitschleife unterbrochen')
    T.indtime   = find(T.time(2:end)==0,1,'first');
    figure(1) % ----------------------------------------------------- %
    clf
    switch Py.eparam
        case 'const'
            subplot(2,1,1)
            plotfield(D.T,M.X,M.Z,Pl,'contourf',...
                '\itT \rm\bf','quiver',ID.vx,ID.vz)
            subplot(2,1,2)
            plotfield(ID.v,M.X,M.Z,Pl,'pcolor',...
                '\itv \rm\bf')
        case 'variable'
            subplot(2,1,1)
            plotfield(D.T,M.X,M.Z,Pl,'contourf',...
                '\itT \rm\bf','quiver',ID.vx,ID.vz)
            subplot(2,2,3)
            plotfield(ID.v,M.X,M.Z,Pl,'pcolor',...
                '\itv \rm\bf')
            subplot(2,2,4)
            plotfield(log10(D.eta),M.X,M.Z,Pl,'pcolor',...
                '\itlog_{10} (\eta) \rm\bf')
    end
    answer = 'yes';
elseif( epsV <= 1e-2 )
    set(figure(1),'position',[1.8,1.8,766.4,780.8]);
    h           =   figure(1);
    T.indtime   = find(T.time(2:end)==0,1,'first');
    disp('Konvektion erreicht steady state.')
    figure(1) % ----------------------------------------------------- %
    clf
    switch Py.eparam
        case 'const'
            subplot(2,1,1)
            plotfield(D.T,M.X,M.Z,Pl,'contourf',...
                '\itT \rm\bf','quiver',ID.vx,ID.vz)
            subplot(2,1,2)
            plotfield(ID.v,M.X,M.Z,Pl,'pcolor',...
                '\itv \rm\bf')
        case 'variable'
            subplot(2,1,1)
            plotfield(D.T,M.X,M.Z,Pl,'contourf',...
                '\itT \rm\bf','quiver',ID.vx,ID.vz)
            subplot(2,2,3)
            plotfield(ID.v,M.X,M.Z,Pl,'pcolor',...
                '\itv \rm\bf')
            subplot(2,2,4)
            plotfield(log10(D.eta),M.X,M.Z,Pl,'pcolor',...
                '\itlog_{10} (\eta) \rm\bf')
    end
    answer = 'yes';
elseif(it == T.itmax)
    T.indtime   = T.itmax;
    disp('Maximale Anzahl der Iterationen erreicht.')
end

end