function PlotTimeSerieses(Py,T,D,M,N,savefig,Ger)

if nargin < 6
    Ger = 0;
    Benchmark = 0;
else
    Benchmark = 1;
end

switch Py.eparam
    case 'const'
        if (Py.eta0 == 1e23)
            blmod   = 1;
        elseif (Py.eta0 == 1e22)
            blmod   = 2;
        elseif (Py.eta0 == 1e21)
            blmod   = 3;
        end
    case 'variable'
        if Py.c == 0
            blmod   = 4;
        else
            blmod   = 5;
        end
end

set(figure(2),'position',[1,1,1536,788.8]);

figure(2)
clf
subplot(4,1,1)
plot(T.time(1:T.indtime),D.Nus(1:T.indtime),...
    'LineWidth',2)
if Benchmark
    hold on
    plot(T.time(1:T.indtime),ones(T.indtime,1).*Ger(1,blmod),'r--')
end
set(gca,'FontWeight','Bold');
xlabel('t'); ylabel('Nus')
title('Nusselt Number')

subplot(4,1,2)
plot(T.time(1:T.indtime),D.meanV(1:T.indtime),...
    'LineWidth',2)
if Benchmark
    hold on
    plot(T.time(1:T.indtime),D.meanV2(1:T.indtime),'r--',...
    'LineWidth',2)
    plot(T.time(1:T.indtime),ones(T.indtime,1).*Ger(2,blmod),'r--')
end
set(gca,'FontWeight','Bold');
xlabel('t'); ylabel('VRMS')
title('Root Mean Square Velocity')

subplot(4,1,3)
% plot(D.meanT(:,T.indtime),M.z,'LineWidth',2)
plot(D.T(:,round(N.nx1/2)),M.z,'LineWidth',2)
if Benchmark
    hold on
    plot(Ger(3,blmod),M.H+Ger(4,blmod),'sk')
    plot(Ger(5,blmod),M.H+Ger(6,blmod),'sk')
end
set(gca,'FontWeight','Bold');
xlabel('T'); ylabel('z')
title('Temperature Profile')

subplot(4,1,4)
plot([D.dTtop(1),D.dTtop(end),-D.dTbot(end),-D.dTbot(1)],'o',...
    'MarkerFaceColor','k')
if Benchmark
    hold on
    plot([Ger(7,blmod),Ger(8,blmod),Ger(9,blmod),Ger(10,blmod)],'s',...
        'MarkerFaceColor','r')
end
set(gca,'FontWeight','Bold','yscale','log');
xlabel('T'); ylabel('z')
title('Temperature Profile')
legend('Model','Benchmark')

switch savefig
    case 'yes'
        saveas(figure(2),['data/Blanckenbach_Ra_',sprintf('%2.2e',Py.Ra),...
            '_eta_',Py.eparam,'_xmax_',num2str(M.xmax),...
            '_nz_',num2str(N.nz),'_TimeSeries'],'png')
end

end