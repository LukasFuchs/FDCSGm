clear
clc

%% Add some paths ------------------------------------------------------- %
if strcmp(getenv('OS'),'Windows_NT')
    addpath('..\DiffusionProblem')
    addpath('..\AdvectionProblem')
    addpath('..\StokesProblem')
    addpath('..\SetUp')
    addpath('..\ScaleParam')
    % Load benchmark data
    Ger     =   load('data\Gerya2019.txt');
else
    addpath('../DiffusionProblem')
    addpath('../AdvectionProblem')
    addpath('../StokesProblem')
    addpath('../SetUp')
    addpath('../ScaleParam')
    % Load benchmark data
    Ger     =   load('data/Gerya2019.txt');
end

T.tstart        =   tic; 

%% Some initial definitions --------------------------------------------- %
Pl.savefig      =   'yes';
Pl.plotfields   =   'yes';

% Define method for solving the energy equation ------------------------- %
B.AdvMethod     =   '?';
B.DiffMethod    =   '?';

% Variable oder konstante Vikositaet ------------------------------------ %

Py.eparam       =   'const';
Py.b            =   log(1000); %log(16384);          % Temperaturabhaengigkeit
Py.c            =   0; %log(64);                  % Tiefenabhaengigkeit
B.EtaIni        =   'tempdep';

% Define initial temperature anomaly ------------------------------------ %
B.Tini          =   '?';
Py.tparam       =   'const'; 

% Define flow field ----------------------------------------------------- %
B.IniFlow       =   '?';
B.FlowFac       =   10;
% ----------------------------------------------------------------------- %

%% --------------------- Definition der Modelkonstanten ----------------- %
M.H         =   -?;          %   Modeltiefe [ in km ]
M.xmax      =   ?;              %   Seitenverhaeltniss
% ----------------------------------------------------------------------- %

%% ------------------- Definition des Numerischen Gitters --------------- %
N.nz        =   ?;             %   Vertikale Gitteraufloesung
N.nx        =   ?;             %   Horizontale Gitteraufloesung
% ----------------------------------------------------------------------- %

%% -------------- Definition Physikalischer Konstanten ------------------ %
Py.g        =   ?;                 %   Schwerebeschleunigung [m/s^2]
Py.rho0     =   ?;               %   Hintergunddichte [kg/m^3]
Py.k        =   ?;                  %   Thermische Leitfaehigkeit [ W/m/K ]
Py.cp       =   ?;               %   Heat capacity [ J/kg/K ]
Py.alpha    =   ?;             %   Thermischer Expnasionskoef. [ K^-1 ]

Py.kappa    =   ?; % 	Thermische Diffusivitaet [ m^2/s ]

Py.Q0       =   0;              % Waermeproduktionsrate pro Volumen [W/m^3]
Py.Q0       =   Py.Q0/Py.rho0;  % Waermeproduktionsrate pro Masse [W/kg]

Py.eta0     =   ?;           %   Viskositaet [ Pa*s ]

Py.DeltaT   =   ?;           % Temperaturdifferenz in K; Tunten - Toben

% Falls Ra < 0 gesetzt ist, dann wird Ra aus den obigen Parametern
% berechnet. Falls Ra gegeben ist, dann wird die Referenzviskositaet so
% angepasst, dass die Skalierungsparameter die gegebene Rayleigh-Zahl
% ergeben.
Py.Ra       =   -999;           % Rayleigh number
% ----------------------------------------------------------------------- %

%% -------------------- Definition der Randbedingungen ------------------ %
% Geschwindigkeitsrandbedingungen --------------------------------------- %
%   0 - no slip; 1 - free slip;
B.tbc       =   ?;              %   Oben
B.bbc       =   ?;              %   Unten
B.lbc       =   ?;              %   Links
B.rbc       =   ?;              %   Rechts

% Thermische Randbedingungen -------------------------------------------- %
B.ttbc      =   '?';
B.btbc      =   '?';
B.ltbc      =   '?';
B.rtbc      =   '?';

% Waermerandbedinungen
% Falls 'flux' - definiert es den Fluss; z.B. 1e-3
% Falls 'const' - definiert es die Temperatur in K
B.lhf       =   ?;
B.rhf       =   ?;
B.thf       =   ?;
B.bhf       =   ?;
% ----------------------------------------------------------------------- %

%% ------------------------ Definition der Zeitkonstanten --------------- %
T.tmax      =   ?;          %   Maximale Zeit in Ma
T.itmax     =   ?;           %   Maximal erlaubte Anzahl der Iterationen
T.dtfac     =   ?;            %   Advektionscourantkriterium
T.dtdifac   =   ?;            %   Diffusions Stabilitaetskriterium


% ----------------------------------------------------------------------- %


% ----------------------------------------------------------------------- %



if Py.Ra < 0
    % Falls die Rayleigh Zahl nicht explizit angegeben wird, wird sie hier
    % berechnet.
    Py.Ra   =   Py.rho0*Py.g*Py.alpha*Py.DeltaT*(-M.H*1e3)^3/Py.eta0/Py.kappa;
else
    % Falls die Rayleigh Zahl gegeben ist müssen wir eine Variable
    % anpassen, z.B. die Referenzviskosität.
    Py.eta0 =   Py.rho0*Py.g*Py.alpha*Py.DeltaT*(-M.H*1e3)^3/Py.Ra/Py.kappa;
end
% ----------------------------------------------------------------------- %


%% ----------------------- Felddefinitionen ----------------------------- %
% Falls eine Strukturvariable schon zuvor definiert wurde, muss diese hier
% der Funktion als Eingabeargument mitgegeben werden. Das Selbe gilt fuer
% aller weiteren Funktionen.
% SetUpFields
% ----------------------------------------------------------------------- %


%% ---------------- Definition der Anfangsbedingungen ------------------- %
% SetUpInitialConditions

% ----------------------------------------------------------------------- %

%% ------------------------- Plot Parameter ----------------------------- %
Pl.inc      =   min(N.nz/10,N.nx/10);
Pl.inc      =   round(Pl.inc);
Pl.xlab     =   '\bfx';
Pl.zlab     =   '\bfz';

switch Pl.plotfields
    case 'yes'
        set(figure(1),'position',[1.8,1.8,766.4,780.8]);
        h           =   figure(1);
end
% ----------------------------------------------------------------------- %

%% Scale Parameters ===================================================== %
[M,N,D,T,S]  = ScaleParameters(M,Py,N,D,T);
% ----------------------------------------------------------------------- %

% Information fuer das Befehlsfenster ----------------------------------- %
fprintf([' Thermische Konvektion fuer Ra = %2.2e:\n  --------------------- ',...
    '\n Diffusion mit: %s',...
    '\n Advektion mit: %s',...
    '\n Viskositaet ist: %s',...
    '\n Anfangstemperaturfeld: %s',...
    '\n Anfangsgeschwindigkeitsfeld: %s',...
    '\n Aufloesung (nx x nz): %i x %i',...
    '\n Refrenzviskositaet [Pa s]: %2.2e',...
    '\n  --------------------- ',...
    '\n '],Py.Ra,B.DiffMethod,B.AdvMethod,Py.eparam,B.Tini,B.IniFlow);
fprintf(['Maximum Time : %1.4g',...
    '\n Maximale Anzahl an Iterationen: %5i',...
    '\n  --------------------- \n'],...
    T.tmax,T.itmax)
% pause
% ----------------------------------------------------------------------- %

%% BEGINN DER ZEITSCHLEIFE ============================================= %%
for it = 1:T.itmax
    %% Erstellung der Koeffizienten Matrix und rechten Seite des
    if(strcmp(B.AdvMethod,'none')==0)
        switch Py.eparam
            case 'const'
                % solveSECE_const_EtaSc
                if (it == 2)
                    N.beenhere = 1;
                end
            case 'variable'
                % solveSECESc
            otherwise
                error('Viskositaet nicht definiert! Siehe Parameter Py.eparam.')
        end
    end
    % ------------------------------------------------------------------- %
    
    %% Berechnung der Zeitschrittlaenge --------------------------------- %
    % Zeitschrittlaenge fuer Advektionsschema
    T.dt        =   ?;
    
    % Zeitschrittlaenge fuer Diffusionsscheme
    T.dtdiff    =   ?;
    
    T.dt        =   min(T.dt,T.dtdiff);
    
    if it>1
        T.time(it)  =   T.time(it-1) + T.dt;
    end
    % ------------------------------------------------------------------- %
    
    %% Interpolation der Geschwindigkeiten auf das regulaere Gitter ----- %
    [ID]        =   InterpStaggered(D,ID,N,'velocity');
    D.meanV(it) = mean(ID.v,'all');   % Mittleregeschwindigkeit
    D.meanV2(it) = rms(ID.vx(:) + ID.vz(:));
    % ------------------------------------------------------------------- %
    
    %% Darstellung der Daten -------------------------------------------- %
    Pl.time     =   ...
        ['@ Iteration: ',sprintf('%i',it),...
        '; Time: ',sprintf('%2.2e',T.time(it))];
    
    if (mod(it,10)==0||it==1)
        switch Pl.plotfields
            case 'yes'                
                figure(1) % --------------------------------------------- %
                clf
                switch Py.eparam
                    case 'const'
                        subplot(2,1,1)
                        plotfield(D.T,M.X,M.Z,Pl,'contourf',...
                            '\itT \rm\bf','quiver',ID.vx,ID.vz)
                        subplot(2,1,2)
                        plotfield(ID.v,M.X,M.Z,Pl,'pcolor',...
                            '\itv \rm\bf')
                    case 'variable'
                        subplot(2,1,1)
                        plotfield(D.T,M.X,M.Z,Pl,'contourf',...
                            '\itT \rm\bf','quiver',ID.vx,ID.vz)
                        subplot(2,2,3)
                        plotfield(ID.v,M.X,M.Z,Pl,'pcolor',...
                            '\itv \rm\bf')
                        subplot(2,2,4)
                        plotfield(log10(D.eta),M.X,M.Z,Pl,'pcolor',...
                            '\itlog_{10} (\eta) \rm\bf')
                        
                end
                
                switch Pl.savefig
                    case 'yes'
                        % Capture the plot as an image
                        frame       = getframe(h);
                        im          = frame2im(frame);
                        [imind,cm]  = rgb2ind(im,256);
                        
                        % Write to the GIF File
                        if it == 1
                            imwrite(imind,cm,Pl.filename,'gif', 'Loopcount',inf);
                        else
                            imwrite(imind,cm,Pl.filename,'gif','WriteMode','append');
                        end
                end
            case 'no'
                disp(['Iteration: ',sprintf('%i',it)])
        end
    end
    % ------------------------------------------------------------------- %
    
    %% Advektion ======================================================== %
    switch B.AdvMethod
        case 'semi-lag'
            if (it==1)
                % SemiLagAdvection2D
                
                % Speicher die alte Geschwindigkeit
                ID.vxo          =   ID.vx;
                ID.vzo          =   ID.vz;
            else
                % SemiLagAdvection2D
            end
    end
    % ------------------------------------------------------------------- %
    
    %% Diffusion ======================================================== %
    switch B.DiffMethod
        case 'explicit'
            % SolveDiff2Dexplicit
        case 'implicit'
            % SolveDiff2Dimplicit
        case 'ADI'
            % SolveDiff2DADI
        case 'none'
        otherwise
            error('Diffusion scheme is not defined!')
    end
    % ------------------------------------------------------------------- %
    
    %% Wärmefluss an der Oberfläche ===================================== %
    D.dTtop         =   (D.T(1,:)-D.T(2,:))./N.dz;
    D.dTbot         =   (D.T(end-1,:)-D.T(end,:))./N.dz;
    %     D.Nus(it)       =   trapz(M.x,D.dTtop).*abs(M.H)/M.L;
    D.Nus(it)       =   mean(D.dTtop);
    
    D.meanT(:,it)   =   mean(D.T,2);
    % ------------------------------------------------------------------- %
    
    %% Variable Viskositaet ============================================= %
    switch Py.eparam
        case 'variable'
            D.eta   =   exp( -Py.b.*((D.T-D.T(1,1))./(D.T(N.nz,1)-D.T(1,1)))...
                + Py.c.*M.Z);
    end
    % ------------------------------------------------------------------- %
    
    [answer,T]  =   CheckBreakCriteria(it,T,D,M,Pl,ID,Py);
    switch answer
        case 'yes'
            break
    end
end
switch Pl.savefig
    case 'yes'
        saveas(figure(1),['data/Blanckenbach_Ra_',sprintf('%2.2e',Py.Ra),...
            '_eta_',Py.eparam,'_xmax_',num2str(M.xmax),...
            '_nz_',num2str(N.nz),'_SS'],'png')
end

%% Darstellen von Zeitparameters ======================================== %
PlotTimeSerieses(Py,T,D,M,N,Pl.savefig,Ger)
% ----------------------------------------------------------------------- %
T.tend      = toc(T.tstart);



if strcmp(getenv('OS'),'Windows_NT')
    rmpath('..\DiffusionProblem')
    rmpath('..\AdvectionProblem')
    rmpath('..\StokesProblem')
    rmpath('..\SetUp')
    rmpath('..\ScaleParam')
else
    rmpath('../DiffusionProblem')
    rmpath('../AdvectionProblem')
    rmpath('../StokesProblem')
    rmpath('../SetUp')
    rmpath('../ScaleParam')
end

% ======================================================================= %
% =============================== END =================================== %
% ======================================================================= %

